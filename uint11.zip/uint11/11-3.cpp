#include<bits/stdc++.h>
using namespace std;
int main(){
    ofstream file;
    file.open("test1.txt");
    file << "已成功写入文件！";
    file.close();
    return 0;
}