#include<bits/stdc++.h>
using namespace std;
int main(){
    int a;
    cout<<"请输入一个十进制整数:";
    cin>>a;
    cout<<dec<<a<<endl;
    cout<<oct<<a<<endl;
    cout<<hex<<a;
    return 0;
}