extern int n;//声明在另一个文件中定义的外部变量n
void fn1(){ //构建fn1函数
    n=3;//将n赋值为3
   
};